#include<iomanip.h>
#include<fstream.h>
#include<stdlib.h>
#include <UDR.hpp>
#include <PrintUdr.hpp>

int main( void )
{
	UdrFormat 	stDataNode;
	CPrintUdr	PrintData;

	ifstream inCredit( "Aggregation.txt", ios::in );

	if( !inCredit )
	{
		cerr << "File could not be opened." << endl;
		exit(1);
	}

	inCredit.read( ( char *)&stDataNode, sizeof( UdrFormat ) );
	while( inCredit && !inCredit.eof() )
	{
		PrintData.Print( &stDataNode );
		inCredit.read( ( char *)&stDataNode, sizeof( UdrFormat ) );
	}
	return 0;
}
