/******************************************************************
* �� �� ��     : Aggregator.cpp 			     					  *
* ��   ��                                                          *
* : Aggregation�� �ϱ� ���� program				                  *
* �� �� ��     : Han Guen Hee                    				  *
* first data  : 2000. 9. 29        	     						  *
* last updata : 2000. 12. 22        		 					  *
* �� �� ȭ ��  : Aggregator.hpp              						  *
* program history                        						  *
*                         	        	 				 		  *
* bug fix                        	     						  *
*                         	        	 						  *
******************************************************************/
#include "Aggregator.hpp"

void sigCapture(int sigNo );
void WritePMSMQ(int sigNo);

// Constructor
CAggregator::CAggregator() 
{
}
//===============================================================
// Constructor Method											=
//  : Aggregation�� �ʿ��� CTransactOfAggregate class ����   		=
// argument : ���μ��� ���󱸺� 6����								=
// return value : None											=
//																=
//===============================================================
CAggregator::CAggregator( int nSystemId, int nServiceId, int nGroupId, int nProcessType, int nPserialNo, int nPreMark )
{
	char   cId='A';
	
	TempLimitMan = new CLimitMan( nServiceId ); 
	sprintf( PATH_NAME_AGGREGATOR, "/SVC%d/DATA/AggShm%d.cfg",nServiceId,nPserialNo );
	sprintf( PATH_NAME_AGGREGATOR_LOG, "/SVC%d/LOG/Aggregation%d.txt",nServiceId,nPserialNo );
	TransactOfAggregate= new CTransactOfAggregate( PATH_NAME_AGGREGATOR, cId,nSystemId,nServiceId,nGroupId,nProcessType,nPserialNo,nPreMark);
	// Btree shared memory�� pointer�� ���´�.
	pBtree = TransactOfAggregate->get_BtreePointer();
	fAggregator.open( PATH_NAME_AGGREGATOR_LOG, ios::out | ios::binary );
	if( !fAggregator )
	{
		*AggregatorLogM << AggregatorLogM->ErrorCode(4207) 
			<< "File could not be opened!!" << endl;
		AggregatorLogM->put_EventHistData(FLAG_END, -1);
		delete AggregatorLogM;
		exit( 1 );
	}
	nUdrCount=0;
	nSumAggregationUdr=0;
}
// destructor
CAggregator::~CAggregator()
{
	delete TransactOfAggregate;
	delete TempLimitMan;
	delete mqPMS;
	delete AggregatorLogM;
	fAggregator.close();
}
//===============================================================
// Aggregator Method						   					=
//  : �ܺο��� Aggregator�� �����Ű�� Method			       		=
//		���� ���� data�� ���ؼ� ȣ���� �޼ҵ带 ����.				=
// argument     :  pUdrFormat -> ó���ϱ� ���� ���� UdrFormat	=
// return value : 0-> success									=
//                -1-> fail										=
//																=
//===============================================================
void CAggregator::Aggregator( UdrFormat* pUdrFormat )
{
	//add jkjung
//	char 		*strTime;
//	int			nLimitInfo;
	
//	if( (nUdrCount == 0) || ((nUdrCount % 1000) == 0) )
//	{
//		strTime = dateTime.get_time(0);
//	}

	// ���� data�� ���� �����ϴ��� �˻��Ѵ�.
	stDataType.iDataKey = pUdrFormat->get_ItemA()->get_unMsId();
	// Memory Lock������ �־�� �Ѵ�.
	pBtree->mem_lock(); // MEMORY LOCK
	pSearchUdrFormat = pBtree->ShowSearch( &stDataType );
	
	if( pSearchUdrFormat == NULL )
	{
		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
			<< "Aggregator : Data Not Exist started aggregator!!" << endl;	
	}
	
	*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
			<< "[ UdrType:" << pUdrFormat->get_ItemHead()->get_nUdrType() << "]" << endl;	
	*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
			<< "[ MsId:" << pUdrFormat->get_ItemA()->get_unMsId() << "]" << endl;	
	*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
			<< "[ nServiceType=" << pUdrFormat->get_ItemHead()->get_nServiceType() << "]" << endl;
	*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
			<< "[ nSubsType=" << pUdrFormat->get_ItemHead()->get_nSubsType() << "]" << endl;
	*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
			<< "[ pUdrFormat AccountSessionID=" << pUdrFormat->get_ItemC()->get_strAccountSessionID() << "]" << endl;
	*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
			<< "[ pUdrFormat CorrelationID=" << pUdrFormat->get_ItemC()->get_strCorrelationID() << "]" << endl;
	*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
			<< "[ pUdrFormat EventTime=" << pUdrFormat->get_ItemG()->get_nEndEventTime() << "]" << endl;
	*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
			<< "[ pSearchUdrFormat EventTime=" << pSearchUdrFormat->get_ItemG()->get_nEndEventTime() << "]" << endl;
	
	// SLA ���-�Ϲ�UDR
	AggregatorLogM->put_PerformanceData(FLAG_ACC,0,pUdrFormat->get_ItemHead()->get_nUdrFileSeq(),1,0,0);
	if( pUdrFormat->get_ItemHead()->get_nSubsType() == 1 )
		// SLA ���-�ѵ�����UDR
		AggregatorLogM->put_PerformanceData(FLAG_ACC,0,pUdrFormat->get_ItemHead()->get_nUdrFileSeq(),0,0,1);
		

	switch( pUdrFormat->get_ItemHead()->get_nUdrType() )
	{

		// INTERIM�� START���
		case START:
			if( _StartProcess( pUdrFormat ) )
			{
				*AggregatorLogM << AggregatorLogM->ErrorCode(4216) 
					<< "Aggregator : _StartProcess Error!!" << endl;	
			}
	 		nUdrCount++;
	 		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
					<< "[Total Udr Count]:" << " " << nUdrCount << endl;	
			break;
		case INTERIM:
			if( _InterimProcess( pUdrFormat ) )
			{
				*AggregatorLogM << AggregatorLogM->ErrorCode(4217) 
					<< "Aggregator : _InterimProcess Error!!" << endl;	
			}
			 nUdrCount++;
			 *AggregatorLogM << AggregatorLogM->ErrorCode(0) 
					<< "[Total Udr Count]:" << " " << nUdrCount << endl;	
			break;
		case STOP:
			if( _StopProcess( pUdrFormat ) )
			{
				*AggregatorLogM << AggregatorLogM->ErrorCode(4218) 
					<< "Aggregator : _StopProcess Error!!" << endl;	
			}
	 		nUdrCount++;
	 		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
					<< "[Total Udr Count]:" << " " << nUdrCount << endl;	
			break;
		// �ѵ������� ���� UDR�� �������� ó��. - 2000. 10. 31
		// Access Request Result
		case 0x81:
			if( !AccessRequestResult( pUdrFormat, pSearchUdrFormat ) )
			{
				*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
					<< "Error Access Request Result Error!!" << endl;	
			}
			else
			{
				*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
					<< "Complete Access Request Result!!" << endl;	
			}
			break;
		// Interim Account Request Result
		case 0x82:
			if( !InterimAccountRequestResult( pUdrFormat, pSearchUdrFormat ) )
			{
				*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
					<< "Error Interim Account Request Result!!" << endl;	
			}
			else
			{
				*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
					<< "Complete Interim Access Request Result!!" << endl;	
			}
			break;
		default:
			// SLA ���-Reject UDR
			AggregatorLogM->put_PerformanceData(FLAG_ACC,0,pUdrFormat->get_ItemHead()->get_nUdrFileSeq(),0,1,0);
			*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "different Udr Type Error !!" << pUdrFormat->get_ItemHead()->get_nUdrType() <<endl;	
			break;
	}	
	pBtree->mem_unlock(); // MEMORY LOCK
	// �������� ������ check.
	if( nUdrCount ==  4294967294 )
		nUdrCount = 0;
	if( nSumAggregationUdr == 4294967294 )
		nSumAggregationUdr=0;
}
//===============================================================
// _StartProcess Method						   					=
//  : START UDR�� �������� �����ϴ� Method			       		=
// argument     :  pUdrFormat -> ó���ϱ� ���� ���� UdrFormat	=
// return value : 0-> success									=
//                -1-> fail										=
//																=
//===============================================================
int CAggregator::_StartProcess( UdrFormat* pUdrFormat )
{
	int			nLimitInfo;
		
	// ���� Data�� �����Ѵٸ�
	if( pSearchUdrFormat != NULL )
	{
		// �̹� ó���� ����� ���¶�� 
		if( pSearchUdrFormat->get_ItemHead()->get_nUdrStatus() == 1)
		{
			// session ID�� ���� ���
			if( !strncmp( pUdrFormat->get_ItemC()->get_strAccountSessionID(), pSearchUdrFormat->get_ItemC()->get_strAccountSessionID(),LEN_ACCOUNT_SESSION_ID ) )
			{
				if(AGGREGATOR_DEBUG)
				{
					// SLA ���-Reject UDR
					AggregatorLogM->put_PerformanceData(FLAG_ACC,0,pUdrFormat->get_ItemHead()->get_nUdrFileSeq(),0,1,0);
					*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
						<< "START -> DATA EXIST -> UDRSTATUS=1(end) -> SAME SessionID" << endl;	
				}
				return 0;
			}
			// session ID�� �ٸ� ���
			else
			{
				// ����data�� ����. ���� Insert
				tStartTime = pUdrFormat->get_ItemG()->get_nEndEventTime();
				pUdrFormat->get_ItemG()->put_nStartEventTime( tStartTime );
				
				// �ѵ������� �ؾ��ϴ� UDR���� �Ǵ��Ѵ�.
				nLimitInfo=TempLimitMan->CompareServiceType( pUdrFormat );
				
				// �ѵ����� UDR�̸� �ѵ���û�� �Ѵ�.
				if( nLimitInfo )
				{
					if( TempLimitMan->LimitAccessRequest( pUdrFormat, nLimitInfo ) )
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "Limit Require Complete!!" << endl;	
					}
					else
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(4222) 
							<< "Aggregator : Limit Require Fail!!!" << endl;	
					}
				}
				else
				{
					*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "Normal UDR " << endl;	
				} 
				 if( UpdateAggregator( pUdrFormat ) )
				 {
				 	*AggregatorLogM << AggregatorLogM->ErrorCode(4224) 
							<< "Aggregator START : UpdateAggregator Error!!!" << endl;	
					 return -1;
				 }
				
				if( AGGREGATOR_DEBUG )
				{
					*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
						<< "START -> DATA EXIST -> UDRSTATUS=1(end) -> Differ SessionID" << endl;	
					*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
						<< "->Run: UpdateAggregator " << endl;	
				}
				 return 0;
			} // else
		} // if
		// ���� ó���ϰ� �ִ� ���¶��
		else if( pSearchUdrFormat->get_ItemHead()->get_nUdrStatus() == 0 )
		{
			// session ID�� ���� ���
			if( !strncmp( pUdrFormat->get_ItemC()->get_strAccountSessionID(), pSearchUdrFormat->get_ItemC()->get_strAccountSessionID(),LEN_ACCOUNT_SESSION_ID ) )
			{
				// ���� ���ε��� �ð��� ������ �ִ� �ð����� �۴ٸ� 
				if( ( pUdrFormat->get_ItemG()->get_nEndEventTime() - pSearchUdrFormat->get_ItemG()->get_nEndEventTime() ) <= 0 )
				{
					if(AGGREGATOR_DEBUG)
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "START -> DATA EXIST -> UDRSTATUS=0 -> Same SessionID -> Small Event Time" << endl;	
					}
					return 0;
				}
				else
				{
					// ���� Active_Time�� �۴ٸ� 
					// ������ DATA�� ó���Ѵ�.
					if( ( pUdrFormat->get_ItemG()->get_nActiveTime() - pSearchUdrFormat->get_ItemG()->get_nActiveTime() ) < 0 )
					{
						if(AGGREGATOR_DEBUG)
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "START -> DATA EXIST -> UDRSTATUS=0 -> Same SessionID -> Big Event Time -> Small Active Time" << endl;	
						}
						return 0;
					}
					else
					{
						
						// ���� start event time�� ����.
						tStartTime = pSearchUdrFormat->get_ItemG()->get_nStartEventTime();
						pUdrFormat->get_ItemG()->put_nStartEventTime( tStartTime );
						// ������ �ѵ������� ������ �ش�.
						pUdrFormat->setLimitInfo( pSearchUdrFormat->get_LimitInfo() );
						_RemainsItem( pSearchUdrFormat, pUdrFormat );
		//				pUdrFormat->setItem( pUdrFormat->get_ItemG() );
					
						// Hand-Off�� �����ؼ� �����Ͱ� �ջ��Ѵ�.
						if( UpdateAggregator( pUdrFormat ) )
				 		{
						    *AggregatorLogM << AggregatorLogM->ErrorCode(4224) 
								<< "Aggregator START : UpdateAggregator Error!!!" << endl;	
							return -1;
				 		}

						if(AGGREGATOR_DEBUG)
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "START -> DATA EXIST -> UDRSTATUS=0 -> Same SessionID -> Big Event Time -> Big Active Time" << endl;	
							*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "->Run: UpdateAggregator" << endl;			
						}
						return 0;
					} // else
				} // else							
			}//  if
			// session ID�� �ٸ� ���
			else
			{
				// ���� ���ε��� �ð��� ������ �ִ� �ð����� �۴ٸ� 
				if( ( pUdrFormat->get_ItemG()->get_nEndEventTime() - pSearchUdrFormat->get_ItemG()->get_nEndEventTime() ) <= 0 )
				{
					if(AGGREGATOR_DEBUG)
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "START -> DATA EXIST -> UDRSTATUS=0 -> Differ SessionID ->Small Event Time" << endl;
					}
					return 0;
				}
				// end�� ������ �ʰ� ���ο� start�� ���۵� data.
				// ������ ���� ��������, ���ο� ����Ÿ�� �ٽ� insert.
				else
				{
					pSearchUdrFormat->get_ItemHead()->put_nUdrStatus(1);
					
					// �ѵ������� �ؾ��ϴ� UDR���� �Ǵ��Ѵ�.
					// ������ ���� �����ؾ� �Ѵ�.( pSearchUdrFormat )
					nLimitInfo=TempLimitMan->CompareServiceType( pSearchUdrFormat );
					 // �ѵ����� UDR�̸� Service End Request
					if( nLimitInfo )
					{
						if( TempLimitMan->LimitServiceEndRequest( pSearchUdrFormat, pSearchUdrFormat, nLimitInfo ) )
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "Limit Require Complete!!" << endl;
						}	
						else
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(4222) 
								<< "Aggregator : Limit Require Fail!!!" << endl;
						}
					}
					else
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "Normal UDR " << endl;
					}
					
				   while(1)
				   {
					   if(MqUdr->sendMsg(pSearchUdrFormat) == FLAG_MQ_IS_FULL)
					   {
					   	   *AggregatorLogM << AggregatorLogM->ErrorCode(4225) 
								<< "Aggregator->Collector MSG Queue FULL!!" << endl;
						   return -1;
					   }
					   else break;
				   }
					nSumAggregationUdr++;
					*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
						<< "Sum Aggregation Udr Count => " << nSumAggregationUdr << endl;
					fAggregator.write( ( char * )pSearchUdrFormat, sizeof( UdrFormat ) );
					fAggregator.flush();
					if( DeleteAggregator( pSearchUdrFormat ) )
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(4226) 
								<< "Aggretator START : DeleteAggregator Error!!" << endl;
						 return -1;
					}
					
					tStartTime = pUdrFormat->get_ItemG()->get_nEndEventTime();
					tStartTime -= pUdrFormat->get_ItemG()->get_nActiveTime();
					pUdrFormat->get_ItemG()->put_nStartEventTime( tStartTime );
					
					nLimitInfo=TempLimitMan->CompareServiceType( pUdrFormat );
					 // �ѵ����� UDR�̸� �ѵ���û�� �Ѵ�.
					if( nLimitInfo )
					{
						if( TempLimitMan->LimitAccessRequest( pUdrFormat, nLimitInfo ) )
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "Limit Require Complete!!" << endl;	
						}	
						else
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(4222) 
								<< "Aggregator : Limit Require Fail!!!" << endl;	
						} 
					}
					else
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "Normal UDR " << endl;
					}
					if( InsertAggregator( pUdrFormat ) )
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(4227) 
							<< "Aggregator START : InsertAggregator Error" << endl;
						return -1;
					}
					if(AGGREGATOR_DEBUG)
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "START -> DATA EXIST -> UDRSTATUS=0 -> Differ SessionID ->Big Event Time" << endl;
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "->Run: Send Old Data -> InsertAggregator" << endl;
					}
					return 0;
				} // else
			} // else
		}// else if
		// �߸��� data�� ���� ���
		else
		{
			*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "nUdrStatus data Error!!" << endl;
			return -1;
		}
	} // if
	// ���� Data�� �������� �ʴ´ٸ�
	else
	{
		tStartTime = pUdrFormat->get_ItemG()->get_nEndEventTime();
		pUdrFormat->get_ItemG()->put_nStartEventTime( tStartTime );
		// �ѵ������� �ؾ��ϴ� UDR���� �Ǵ��Ѵ�.
		nLimitInfo=TempLimitMan->CompareServiceType( pUdrFormat );
		
		 // �ѵ����� UDR�̸� �ѵ���û�� �Ѵ�.
		if( nLimitInfo )
		{
			if( TempLimitMan->LimitAccessRequest( pUdrFormat, nLimitInfo ) )
			{
				*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
					<< "Limit Require Complete!!" << endl;	
			}	
			else
			{
				*AggregatorLogM << AggregatorLogM->ErrorCode(4222) 
					<< "Aggregator : Limit Require Fail!!!" << endl;
			} 
		}
		else
		{
			*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
					<< "Normal UDR " << endl;
		}
		// ������ Data. ���������� insert.
		if( InsertAggregator( pUdrFormat ) )
		{
			*AggregatorLogM << AggregatorLogM->ErrorCode(4227) 
					<< "Aggregator START : InsertAggregator Error" << endl;
			return -1;
		}
		if(AGGREGATOR_DEBUG)
		{
			*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
					<< "START -> DATA Not EXIST" << endl;
			*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
					<< "->Run: InsertAggregator" << endl;
		}
		return 0;
	} // else
}
//===============================================================
// _InterimProcess Method					   					=
//  : INTERIM UDR�� �������� �����ϴ� Method			       		=
// argument     :  pUdrFormat -> ó���ϱ� ���� ���� UdrFormat	=
// return value : 0-> success									=
//                -1-> fail										=
//																=
//===============================================================
int CAggregator::_InterimProcess( UdrFormat* pUdrFormat )
{
	int			nLimitInfo;
	
	// update�ϰ��� �ϴ� data�� �����Ѵٸ�
	if( pSearchUdrFormat != NULL )
	{
		// �̹� ó���� ����� ���¶�� 
		if( pSearchUdrFormat->get_ItemHead()->get_nUdrStatus() == 1)
		{
			// session ID�� ���� ���
			if( !strncmp( pUdrFormat->get_ItemC()->get_strAccountSessionID(), pSearchUdrFormat->get_ItemC()->get_strAccountSessionID(),LEN_ACCOUNT_SESSION_ID ) )
			{
				// ���� ���ε��� �ð��� ������ �ִ� �ð����� �۴ٸ� 
				if( ( pUdrFormat->get_ItemG()->get_nEndEventTime() - pSearchUdrFormat->get_ItemG()->get_nEndEventTime() ) <= 0 )
				{
					if(AGGREGATOR_DEBUG)
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "INTERIM -> DATA EXIST -> UDRSTATUS=1 -> Same SessionID -> Small Event time" << endl;
					}
					return 0;
				}
				else
				{
					// Active time ��ȭ��, Dormant���� Active��
					// �ű� Aggregation�� ����
					// ���� Active_Time�� �۴ٸ� 
					// ������ DATA�� ó���Ѵ�.
					if( ( pUdrFormat->get_ItemG()->get_nActiveTime() - pSearchUdrFormat->get_ItemG()->get_nActiveTime() ) < 0 )
					{
						if(AGGREGATOR_DEBUG)
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "INTERIM -> DATA EXIST -> UDRSTATUS=1 -> Same SessionID -> Big Event time -> Small Active Time" << endl;
						}
						return 0;
					}
					else
					{
						// ���� start time�� �����´�.
						// update���ش�.
						tStartTime = pSearchUdrFormat->get_ItemG()->get_nStartEventTime();
						pUdrFormat->get_ItemG()->put_nStartEventTime( tStartTime );
						
						// �ѵ������� �ؾ��ϴ� UDR���� �Ǵ��Ѵ�.
						nLimitInfo=TempLimitMan->CompareServiceType( pUdrFormat );
						
						// ������ ������ �������ִ� ���
						_RemainsItem( pSearchUdrFormat, pUdrFormat );
						
						 // �ѵ����� UDR�̸� �ѵ���û�� �Ѵ�.
						if( nLimitInfo )
						{
							if( TempLimitMan->LimitAccessRequest( pUdrFormat, nLimitInfo ) )
							{
								*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
									<< "Limit Require Complete!!" << endl;	
							}	
							else
							{
								*AggregatorLogM << AggregatorLogM->ErrorCode(4222) 
									<< "Aggregator : Limit Require Fail!!!" << endl;
							} 
						}
						else
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "Normal UDR " << endl;
						}
						if( UpdateAggregator( pUdrFormat ) )
				 		{
							*AggregatorLogM << AggregatorLogM->ErrorCode(4224) 
								<< "Aggregator : UpdateAggregator Error!!!" << endl;
							 return -1;
				 		}

						if(AGGREGATOR_DEBUG)
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "INTERIM -> DATA EXIST -> UDRSTATUS=1 -> Same SessionID -> Big Event Time -> Big Active Time" << endl;
							*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "->Run: UpdateAggregator" << endl;
						}
						return 0;
					} // else
				} // else						
			} // if
			// session ID�� �ٸ� ���
			else
			{
				// ���� ���ε��� �ð��� ������ �ִ� �ð����� �۴ٸ� 
				if( ( pUdrFormat->get_ItemG()->get_nEndEventTime() - pSearchUdrFormat->get_ItemG()->get_nEndEventTime() ) <= 0 )
				{
					if(AGGREGATOR_DEBUG)
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "INTERIM -> DATA EXIST -> UDRSTATUS=1 -> differ SessionID -> Small Event Time" << endl;
					}
					return 0;
				}
				else
				{
					// Start Udr �н�.
					// �ű� Aggregation ����
					// ���� ���� end time�� start time���� ��ȯ��,
					// update���ش�.
					tStartTime = pUdrFormat->get_ItemG()->get_nEndEventTime();
					tStartTime -= pUdrFormat->get_ItemG()->get_nActiveTime();
					pUdrFormat->get_ItemG()->put_nStartEventTime( tStartTime );
					// �ѵ������� �ؾ��ϴ� UDR���� �Ǵ��Ѵ�.
					nLimitInfo=TempLimitMan->CompareServiceType( pUdrFormat );
					
					 // �ѵ����� UDR�̸� �ѵ���û�� �Ѵ�.
					if( nLimitInfo )
					{
						if( TempLimitMan->LimitAccessRequest( pUdrFormat, nLimitInfo ) )
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "Limit Require Complete!!" << endl;	
						}	
						else
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(4222) 
								<< "Aggregator : Limit Require Fail!!!" << endl;
						} 
					}
					else
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "Normal UDR " << endl;
					}
					if( UpdateAggregator( pUdrFormat ) )
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(4224) 
								<< "Aggregator : UpdateAggregator Error!!!" << endl;
						return -1;
					}
					if(AGGREGATOR_DEBUG)
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "INTERIM -> DATA EXIST -> UDRSTATUS=1 -> differ SessionID -> Big Event Time" << endl;
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "->Run: UpdateAggregator" << endl;
					}
					return 0;
				} // else						
			} // else
		} // if
		// ���� ó���ϰ� �ִ� ���¶��
		else if( pSearchUdrFormat->get_ItemHead()->get_nUdrStatus() == 0 )
		{
			// session ID�� ���� ���
			if( !strncmp( pUdrFormat->get_ItemC()->get_strAccountSessionID(), pSearchUdrFormat->get_ItemC()->get_strAccountSessionID(),LEN_ACCOUNT_SESSION_ID ) )
			{
				// ���� ���ε��� �ð��� ������ �ִ� �ð����� �۴ٸ� 
				if( ( pUdrFormat->get_ItemG()->get_nEndEventTime() - pSearchUdrFormat->get_ItemG()->get_nEndEventTime() ) < 0 )
				{
					if(AGGREGATOR_DEBUG)
					{
						// ���� UDR�� ����.	
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "INTERIM -> DATA EXIST -> UDRSTATUS=0 -> Same SessionID ->Small Event Time" << endl;				
					}
					return 0;
				}
				else
				{
					// ����ó�� �����Ͱ� �ջ��Ѵ�.
					// ���� Active_Time�� �۴ٸ� 
					// ������ DATA�� ó���Ѵ�.
				 	if( ( pUdrFormat->get_ItemG()->get_nActiveTime() - pSearchUdrFormat->get_ItemG()->get_nActiveTime() ) < 0 )
					{
						if(AGGREGATOR_DEBUG)
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "INTERIM -> DATA EXIST -> UDRSTATUS=0 -> Same SessionID -> Big Event Time -> Small Active Time" << endl;	
						}
						return 0;
					}
					else
					{
						// ���� start time�� ���ε��� UDR�� start time�� �־��ְ�, 
						// update���ش�.
						tStartTime = pSearchUdrFormat->get_ItemG()->get_nStartEventTime();
						pUdrFormat->get_ItemG()->put_nStartEventTime( tStartTime );
						
						// �ѵ������� �ؾ��ϴ� UDR���� �Ǵ��Ѵ�.
						// ���� ������ service type�� ��.
						TempLimitMan->CompareLimitInfo( pUdrFormat,pSearchUdrFormat );
						nLimitInfo=TempLimitMan->CompareServiceType( pUdrFormat );
						
						// ������ ������ �������ִ� ���
						_RemainsItem( pSearchUdrFormat, pUdrFormat );
						
						 // �ѵ����� UDR�̸� �ѵ���û�� �Ѵ�.
						if( nLimitInfo )
						{
							if( TempLimitMan->LimitInterimAccountRequest( pUdrFormat, pSearchUdrFormat, nLimitInfo ) )
							{
								*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
									<< "Limit Require Complete!!" << endl;
							}	
							else
							{
								*AggregatorLogM << AggregatorLogM->ErrorCode(4222) 
									<< "Aggregator : Limit Require Fail!!!" << endl;
							} 
						}
						else
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "Normal UDR " << endl;
						}
						
						if( UpdateAggregator( pUdrFormat ) )
				 		{
							*AggregatorLogM << AggregatorLogM->ErrorCode(4224) 
								<< "Aggregator : UpdateAggregator Error!!!" << endl;
							return -1;
				 		}

						if(AGGREGATOR_DEBUG)
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "INTERIM -> DATA EXIST -> UDRSTATUS=0 -> Same SessionID -> Big Event Time -> Big Active Time" << endl;
							*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "->Run: UpdateAggregator" << endl;
						}
						return 0;
					} // else
				} // else
			} // if
			// session ID�� �ٸ� ���
			else
			{
				// ���� ���ε��� �ð��� ������ �ִ� �ð����� �۴ٸ� 
				if( ( pUdrFormat->get_ItemG()->get_nEndEventTime() - pSearchUdrFormat->get_ItemG()->get_nEndEventTime() ) <= 0 )
				{
					if(AGGREGATOR_DEBUG)
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "INTERIM -> DATA EXIST -> UDRSTATUS=0 -> Differ SessionID -> Small Event Time" << endl;
					}
					return 0;
				}
				// stop, start UDR �н�.
				// ������ ���� ��������, ���ο� ����Ÿ�� �ٽ� insert.
				else
				{
					pSearchUdrFormat->get_ItemHead()->put_nUdrStatus(1);
					// �ѵ������� �ؾ��ϴ� UDR���� �Ǵ��Ѵ�.
					nLimitInfo=TempLimitMan->CompareServiceType( pSearchUdrFormat );
					 // �ѵ����� UDR�̸� Service End Request
					if( nLimitInfo )
					{
						if( TempLimitMan->LimitServiceEndRequest( pSearchUdrFormat, pSearchUdrFormat, nLimitInfo ) )
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "Limit Require Complete!!" << endl;
						}	
						else
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(4222) 
								<< "Aggregator : Limit Require Fail!!!" << endl;
						}
					}
					else
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "Normal UDR " << endl;
					}
				   	while(1)
				   	{
					    if(MqUdr->sendMsg(pSearchUdrFormat) == FLAG_MQ_IS_FULL)
						{
						    *AggregatorLogM << AggregatorLogM->ErrorCode(4225) 
								<< "Aggregator->Collector MSG Queue FULL!!" << endl;
							return -1;
						}
					    else break;
				   	}
					nSumAggregationUdr++;
					*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
						<< "Sum Aggregation Udr Count => " << nSumAggregationUdr << endl;
					fAggregator.write( ( char * )pSearchUdrFormat, sizeof( UdrFormat ) );
					fAggregator.flush();
					if( DeleteAggregator( pSearchUdrFormat ) )
					{
						 *AggregatorLogM << AggregatorLogM->ErrorCode(4226) 
								<< "Aggretator : DeleteAggregator Error!!" << endl;
						 return -1;
					}
					// ���� ���� end time�� start time���� ��ȯ��,
					// insert���ش�.
					tStartTime = pUdrFormat->get_ItemG()->get_nEndEventTime();
					tStartTime -= pUdrFormat->get_ItemG()->get_nActiveTime();
					pUdrFormat->get_ItemG()->put_nStartEventTime( tStartTime );
					
					nLimitInfo=TempLimitMan->CompareServiceType( pUdrFormat );
					 // �ѵ����� UDR�̸� �ѵ���û�� �Ѵ�.
					if( nLimitInfo)
					{
						if( TempLimitMan->LimitAccessRequest( pUdrFormat, nLimitInfo ) )
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "Limit Require Complete!!" << endl;
						}	
						else
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(4222) 
								<< "Aggregator : Limit Require Fail!!!" << endl;
						} 
					}
					else
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "Normal UDR " << endl;
					}
					if( InsertAggregator( pUdrFormat ) )
					{
					 	*AggregatorLogM << AggregatorLogM->ErrorCode(4227) 
							<< "Aggregator START : InsertAggregator Error" << endl;
						return -1;
					}
					if(AGGREGATOR_DEBUG)
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "INTERIM -> DATA EXIST -> UDRSTATUS=0 -> Differ SessionID -> Big Event Time" << endl;
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "->Run: Send Old Data -> InsertAggregator" << endl;
					}
					return 0;
				} // else
			} //else 
		} // else if
		// �߸��� data�� ���� ���
		else
		{
			*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
					<< "nUdrStatus data Error!!" << endl;
			return -1;
		}
	} // if
	// non-exist data
	else
	{
		// start�� �Ҿ���� data�� �����Ѵ�.
		// ���� ���� end time�� start time���� ��ȯ��,
		// insert���ش�.
		tStartTime = pUdrFormat->get_ItemG()->get_nEndEventTime();
		tStartTime -= pUdrFormat->get_ItemG()->get_nActiveTime();
		pUdrFormat->get_ItemG()->put_nStartEventTime( tStartTime );
		// �ѵ������� �ؾ��ϴ� UDR���� �Ǵ��Ѵ�.
		nLimitInfo=TempLimitMan->CompareServiceType( pUdrFormat );
	
		// �ѵ����� UDR�̸� �ѵ���û�� �Ѵ�.
		if( nLimitInfo )
		{
			if( TempLimitMan->LimitAccessRequest( pUdrFormat, nLimitInfo ) )
			{
				*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
					<< "Limit Require Complete!!" << endl;
			}	
			else
			{
				*AggregatorLogM << AggregatorLogM->ErrorCode(4222) 
					<< "Aggregator : Limit Require Fail!!!" << endl;
			}
		}
		else
		{
			*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "Normal UDR " << endl;
		}
		if( InsertAggregator( pUdrFormat ) )
		{
			 *AggregatorLogM << AggregatorLogM->ErrorCode(4227) 
					<< "Aggregator START : InsertAggregator Error" << endl;
			return -1;
		}
		if(AGGREGATOR_DEBUG)
		{
			*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "INTERIM -> DATA Not EXIST" << endl;
			*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "->Run: InsertAggregator" << endl;
		}
		return 0;
	} // else
}
//===============================================================
// _StopProcess Method						   					=
//  : STOP UDR�� �������� �����ϴ� Method				       		=
// argument     :  pUdrFormat -> ó���ϱ� ���� ���� UdrFormat	=
// return value : 0-> success									=
//                -1-> fail										=
//																=
//===============================================================
int CAggregator::_StopProcess( UdrFormat* pUdrFormat )
{
	int			nLimitInfo;
	
	// delete�ϰ��� �ϴ� data�� �����Ѵٸ�
	if( pSearchUdrFormat != NULL )
	{
		// �̹� ó���� ����� ���¶�� 
		if( pSearchUdrFormat->get_ItemHead()->get_nUdrStatus() == 1)
		{
			// session ID�� ���� ���
			if( !strncmp( pUdrFormat->get_ItemC()->get_strAccountSessionID(), pSearchUdrFormat->get_ItemC()->get_strAccountSessionID(),LEN_ACCOUNT_SESSION_ID ) )
			{
				if(AGGREGATOR_DEBUG)
				{
					*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
						<< "STOP -> DATA EXIST -> UDRSTATUS=1 -> Same SessionID ->Small Event Time" << endl;	
				}
				return 0;	
			}
			// session ID�� �ٸ� ���
			else
			{
				// ���� ���ε��� �ð��� ������ �ִ� �ð����� �۴ٸ� 
				if( ( pUdrFormat->get_ItemG()->get_nEndEventTime() - pSearchUdrFormat->get_ItemG()->get_nEndEventTime() ) <= 0 )
				{
					if(AGGREGATOR_DEBUG)
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "STOP -> DATA EXIST -> UDRSTATUS=1 -> differ SessionID -> Small Event Time" << endl;	
					}	

					return 0;
				}
				else
				{
					// Start, Interim Udr �н�.
					// �ű� session�� ���� ����.
					tStartTime = pUdrFormat->get_ItemG()->get_nEndEventTime();
					tStartTime -= pUdrFormat->get_ItemG()->get_nActiveTime();
					pUdrFormat->get_ItemG()->put_nStartEventTime( tStartTime );
					pUdrFormat->get_ItemHead()->put_nUdrStatus(1);
					 // �ѵ������� �ؾ��ϴ� UDR���� �Ǵ��Ѵ�.
					nLimitInfo=TempLimitMan->CompareServiceType( pUdrFormat );
						
				     // �ѵ����� UDR�̸� �ѵ���û�� �Ѵ�.
					if( nLimitInfo )
					{
						// UDR�� LIMIT_INFO�κ��� ä���ش�.
						// Start�� �ش��ϴ� ������.
						pUdrFormat->get_LimitInfo()->put_nOperationID( 0 );
						pUdrFormat->get_LimitInfo()->put_nSessionStartTime( pUdrFormat->get_ItemG()->get_nStartEventTime() );
						pUdrFormat->get_LimitInfo()->put_nSessionEndTime( pUdrFormat->get_ItemG()->get_nEndEventTime() );
						pUdrFormat->get_LimitInfo()->put_nSessionCount( 0 );
						pUdrFormat->get_LimitInfo()->put_nLimitPrice( 0 );
						pUdrFormat->get_LimitInfo()->put_nNtopFreeTime( 0 );
						pUdrFormat->get_LimitInfo()->put_nRemain( 0 );
						pUdrFormat->get_LimitInfo()->put_nQueryResult( 0 );
						if( TempLimitMan->LimitServiceEndRequest( pUdrFormat, pUdrFormat, nLimitInfo ) )
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "Limit Require Complete!!" << endl;
						}	
						else
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(4222) 
								<< "Aggregator : Limit Require Fail!!!" << endl;
						}
					}
					else
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "Normal UDR " << endl;
					}
					if( UpdateAggregator( pUdrFormat ) )
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(4224) 
								<< "Aggregator : UpdateAggregator Error!!!" << endl;
					    cout.flush();
						return -1;
					}
				   	while(1)
				   	{
					    if(MqUdr->sendMsg(pUdrFormat) == FLAG_MQ_IS_FULL)
						{
						    *AggregatorLogM << AggregatorLogM->ErrorCode(4225) 
								<< "Aggregator->Collector MSG Queue FULL!!" << endl;
							return -1;
						}
					    else break;
				   	}
					nSumAggregationUdr++;
					*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
						<< "Sum Aggregation Udr Count => " << nSumAggregationUdr << endl;
					fAggregator.write( ( char * )pUdrFormat, sizeof( UdrFormat ) );
					fAggregator.flush();

					if(AGGREGATOR_DEBUG)
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "STOP -> DATA EXIST -> UDRSTATUS=1 -> differ SessionID-> Big Event Time" << endl;
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "->Run: UpdateAggregator -> Send Data" << endl;
					}
					return 0;
				} // else						
			} // else
		} // if
		// ���� ó���ϰ� �ִ� ���¶��
		else if( pSearchUdrFormat->get_ItemHead()->get_nUdrStatus() == 0 )
		{
			// session ID�� ���� ���
			if( !strncmp( pUdrFormat->get_ItemC()->get_strAccountSessionID(), pSearchUdrFormat->get_ItemC()->get_strAccountSessionID(),LEN_ACCOUNT_SESSION_ID ) )
			{
				// ���� ���ε��� �ð��� ������ �ִ� �ð����� �۴ٸ� 
				if( ( pUdrFormat->get_ItemG()->get_nEndEventTime() - pSearchUdrFormat->get_ItemG()->get_nEndEventTime() ) < 0 )
				{
					if(AGGREGATOR_DEBUG)
					{
						// ���� UDR�� ����.
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "STOP -> DATA EXIST -> UDRSTATUS=0 -> Same SessionID -> Small Event Time" << endl;					
					}
					return 0;
				}
				// ����ó�� ���� session ����.
				else
				{
					// ���� Active_Time�� �۴ٸ� 
					// ������ DATA�� ó���Ѵ�.
				 	if( ( pUdrFormat->get_ItemG()->get_nActiveTime() - pSearchUdrFormat->get_ItemG()->get_nActiveTime() ) < 0 )
					{
						if(AGGREGATOR_DEBUG)
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "STOP -> DATA EXIST -> UDRSTATUS(0) -> Same SessionID->Big EVent time -> Small Active Time" << endl;
						}
						return 0;
					}
					else
					{
						// ���� data�� ǥ�����ִ� flag.
						pUdrFormat->get_ItemHead()->put_nUdrStatus(1);
						tStartTime = pSearchUdrFormat->get_ItemG()->get_nStartEventTime();
						pUdrFormat->get_ItemG()->put_nStartEventTime( tStartTime );
						
					    // �ѵ������� �ؾ��ϴ� UDR���� �Ǵ��Ѵ�.
					    // ���� ������ service type�� ��.
						TempLimitMan->CompareLimitInfo( pUdrFormat,pSearchUdrFormat );
						nLimitInfo=TempLimitMan->CompareServiceType( pUdrFormat );
						
						// ������ ������ �������ִ� ���
						_RemainsItem( pSearchUdrFormat, pUdrFormat );
					     // �ѵ����� UDR�̸� �ѵ���û�� �Ѵ�.
						if( nLimitInfo )
						{
							if( TempLimitMan->LimitServiceEndRequest( pUdrFormat, pSearchUdrFormat, nLimitInfo ) )
							{
								*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
									<< "Limit Require Complete!!" << endl;
							}	
							else
							{
								*AggregatorLogM << AggregatorLogM->ErrorCode(4222) 
									<< "Aggregator : Limit Require Fail!!!" << endl;
							}
						}
						else
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "Normal UDR " << endl;
						}
					    if( UpdateAggregator( pUdrFormat ) )
					    {
							*AggregatorLogM << AggregatorLogM->ErrorCode(4224) 
								<< "Aggregator : UpdateAggregator Error!!!" << endl;
							return -1;
				  	 	}
				   		while(1)
				   		{
					    	if(MqUdr->sendMsg(pUdrFormat) == FLAG_MQ_IS_FULL)
							{
							    *AggregatorLogM << AggregatorLogM->ErrorCode(4225) 
									<< "Aggregator->Collector MSG Queue FULL!!" << endl;
								return -1;
							}
					    	else break;
					   	}
						nSumAggregationUdr++;
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "Sum Aggregation Udr Count => " << nSumAggregationUdr << endl;
						fAggregator.write( ( char * )pUdrFormat, sizeof( UdrFormat ) );
						fAggregator.flush();
						// ���� data�� ���������ʰ� ���ܵд�.

						if(AGGREGATOR_DEBUG)
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "STOP -> DATA EXIST -> UDRSTATUS=0 -> Same SessionID -> Big Event Time -> Big Active Time" << endl;
							*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "->Run: UpdateAggregator -> Send Data" << endl;
						}
						return 0;
					} // else
				} // else	
			} // if
			// session ID�� �ٸ� ���
			else
			{
				// ���� ���ε��� �ð��� ������ �ִ� �ð����� �۴ٸ� 
				if( ( pUdrFormat->get_ItemG()->get_nEndEventTime() - pSearchUdrFormat->get_ItemG()->get_nEndEventTime() ) <= 0 )
				{
					if(AGGREGATOR_DEBUG)
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "STOP -> DATA EXIST -> UDRSTATUS(0) -> differ SessionID-> Small Event Time" << endl;
					}
					return 0;
				}
				// stop, start, Interim UDR �н�.
				// ������ ���� ��������, ���ο� ����Ÿ�� �ٽ� insert�� �����Ų��.
				else
				{
					// ���� session ����.
					pSearchUdrFormat->get_ItemHead()->put_nUdrStatus(1);
					 // �ѵ������� �ؾ��ϴ� UDR���� �Ǵ��Ѵ�.
					nLimitInfo=TempLimitMan->CompareServiceType( pSearchUdrFormat );
					
				     // �ѵ����� UDR�̸� �ѵ���û�� �Ѵ�.
					if( nLimitInfo )
					{
						if( TempLimitMan->LimitServiceEndRequest( pSearchUdrFormat, pSearchUdrFormat, nLimitInfo ) )
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "Limit Require Complete!!" << endl;
						}	
						else
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(4222) 
								<< "Aggregator : Limit Require Fail!!!" << endl;
						}
					}
					else
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "Normal UDR " << endl;
					}
				   	while(1)
				   	{
					    if(MqUdr->sendMsg(pSearchUdrFormat) == FLAG_MQ_IS_FULL)
						{
						    *AggregatorLogM << AggregatorLogM->ErrorCode(4225) 
								<< "Aggregator->Collector MSG Queue FULL!!" << endl;
							return -1;
                        }
					   	else break;
				   	}
					nSumAggregationUdr++;
					*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
						<< "Sum Aggregation Udr Count => " << nSumAggregationUdr << endl;
					fAggregator.write( ( char * )pSearchUdrFormat, sizeof( UdrFormat ) );
					fAggregator.flush();
					if( DeleteAggregator( pSearchUdrFormat ) )
					{
						  *AggregatorLogM << AggregatorLogM->ErrorCode(4226) 
								<< "Aggretator : DeleteAggregator Error!!" << endl;
						 return -1;
					}
					// ���ο� DATA�� Insert���� ����.
					pUdrFormat->get_ItemHead()->put_nUdrStatus(1);
					tStartTime = pUdrFormat->get_ItemG()->get_nEndEventTime();
					tStartTime -= pUdrFormat->get_ItemG()->get_nActiveTime();
					pUdrFormat->get_ItemG()->put_nStartEventTime( tStartTime );
					
					nLimitInfo=TempLimitMan->CompareServiceType( pUdrFormat );
				     // �ѵ����� UDR�̸� �ѵ���û�� �Ѵ�.
					if( nLimitInfo )
					{
						//UDR�� LIMIT_INFO�κ��� ä���ش�.
						// Start�� �ش��ϴ� ������.
						pUdrFormat->get_LimitInfo()->put_nOperationID( 0 );
						pUdrFormat->get_LimitInfo()->put_nSessionStartTime( pUdrFormat->get_ItemG()->get_nStartEventTime() );
						pUdrFormat->get_LimitInfo()->put_nSessionEndTime( pUdrFormat->get_ItemG()->get_nEndEventTime() );
						pUdrFormat->get_LimitInfo()->put_nSessionCount( 0 );
						pUdrFormat->get_LimitInfo()->put_nLimitPrice( 0 );
						pUdrFormat->get_LimitInfo()->put_nNtopFreeTime( 0 );
						pUdrFormat->get_LimitInfo()->put_nRemain( 0 );
						pUdrFormat->get_LimitInfo()->put_nQueryResult( 0 );
						if( TempLimitMan->LimitServiceEndRequest( pUdrFormat, pUdrFormat, nLimitInfo ) )
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
								<< "Limit Require Complete!!" << endl;
						}	
						else
						{
							*AggregatorLogM << AggregatorLogM->ErrorCode(4222) 
								<< "Aggregator : Limit Require Fail!!!" << endl;
						}
					}
					else
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "Normal UDR " << endl;
					}
					if( InsertAggregator( pUdrFormat ) )
					{
					 	*AggregatorLogM << AggregatorLogM->ErrorCode(4227) 
							<< "Aggregator START : InsertAggregator Error" << endl;
						return -1;
					}
				   	while(1)
				   	{
					    if(MqUdr->sendMsg(pUdrFormat) == FLAG_MQ_IS_FULL)
						{
						    *AggregatorLogM << AggregatorLogM->ErrorCode(4225) 
								<< "Aggregator->Collector MSG Queue FULL!!" << endl;
							return -1;
						}
					   	else break;
				   	}
					nSumAggregationUdr++;
					*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
						<< "Sum Aggregation Udr Count => " << nSumAggregationUdr << endl;
					fAggregator.write( ( char * )pUdrFormat, sizeof( UdrFormat ) );
					fAggregator.flush();

					if(AGGREGATOR_DEBUG)
					{
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "STOP -> DATA EXIST -> UDRSTATUS(0) -> differ SessionID -> Big Event Time" << endl;
						*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
							<< "->Run: Send Old Data -> InsertAggregator -> Send New Data" << endl;
					}
					return 0;
				} // else
			} // else
		} // else if
	} // if
	// non-exist data
	else
	{
		// �ű� session�� ����� insert����, 
		// flag�� setting�ϰ� �����Ų��.
		// ���Ŀ� �̹� ó���� �Ŀ� ������ STOP�� 
		// active time�� interval�� ���Ͽ� ó���Ѵ�. 
		pUdrFormat->get_ItemHead()->put_nUdrStatus(1);
		tStartTime = pUdrFormat->get_ItemG()->get_nEndEventTime();
		tStartTime -= pUdrFormat->get_ItemG()->get_nActiveTime();
		pUdrFormat->get_ItemG()->put_nStartEventTime( tStartTime );
		 // �ѵ������� �ؾ��ϴ� UDR���� �Ǵ��Ѵ�.
		nLimitInfo=TempLimitMan->CompareServiceType( pUdrFormat );
				
		// �ѵ����� UDR�̸� �ѵ���û�� �Ѵ�.
		if( nLimitInfo )
		{
			//UDR�� LIMIT_INFO�κ��� ä���ش�.
			// Start�� �ش��ϴ� ������.
			pUdrFormat->get_LimitInfo()->put_nOperationID( 0 );
			pUdrFormat->get_LimitInfo()->put_nSessionStartTime( pUdrFormat->get_ItemG()->get_nStartEventTime() );
			pUdrFormat->get_LimitInfo()->put_nSessionEndTime( pUdrFormat->get_ItemG()->get_nEndEventTime() );
			pUdrFormat->get_LimitInfo()->put_nSessionCount( 0 );
			pUdrFormat->get_LimitInfo()->put_nLimitPrice( 0 );
			pUdrFormat->get_LimitInfo()->put_nNtopFreeTime( 0 );
			pUdrFormat->get_LimitInfo()->put_nRemain( 0 );
			pUdrFormat->get_LimitInfo()->put_nQueryResult( 0 );
			if( TempLimitMan->LimitServiceEndRequest( pUdrFormat, pUdrFormat, nLimitInfo ) )
			{
				*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
					<< "Limit Require Complete!!" << endl;
			}	
			else
			{
				*AggregatorLogM << AggregatorLogM->ErrorCode(4222) 
					<< "Aggregator : Limit Require Fail!!!" << endl;
			}
		}
		else
		{
			*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "Normal UDR " << endl;
		}
		if( InsertAggregator( pUdrFormat ) )
		{
		 	*AggregatorLogM << AggregatorLogM->ErrorCode(4227) 
				<< "Aggregator START : InsertAggregator Error" << endl;
			return -1;
		}
	   	while(1)
	   	{
		    if(MqUdr->sendMsg(pUdrFormat) == FLAG_MQ_IS_FULL)
			{
			     *AggregatorLogM << AggregatorLogM->ErrorCode(4225) 
					<< "Aggregator->Collector MSG Queue FULL!!" << endl;
				return -1;
			}
		   	else break;
	   	}
		nSumAggregationUdr++;
		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
			<< "Sum Aggregation Udr Count => " << nSumAggregationUdr << endl;
		fAggregator.write( ( char * )pUdrFormat, sizeof( UdrFormat ) );
		fAggregator.flush();

		if(AGGREGATOR_DEBUG)
		{
			*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "STOP -> DATA Not EXIST" << endl;
			*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "->Run: InsertAggregator -> Send New Data" << endl;
		}
		return 0;
	} // else
}
//===============================================================
// AccessRequestResult Method				   					=
//  : SCP�κ��� �ѵ�������û�� ���� ������ ������ ó���ϴ� Method  		=
// argument     :  pUdrFormat -> ó���ϱ� ���� ���� UdrFormat	=
//				   pSearchUdrFormat -> ������ MDB�� �ִ� DATA		=
// return value : 1-> success									=
//                0-> fail										=
//																=
//===============================================================
int	CAggregator::AccessRequestResult( UdrFormat* pUdrFormat, UdrFormat* pSearchUdrFormat )
{
	int 		nNewOperationID;
	int 		nLastOperationID;
	int		 	nTempNewPrice;
	int 		nTempNewTime;
	UdrFormat*	pTempUdrFormat;
	
	// �ӽ� ��������� �Ҵ��Ѵ�.
	pTempUdrFormat = new UdrFormat;
	
	if( 1 )
	{
		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
			<< "============ ������ ������ȸ ��� ===========" <<  endl;
		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "MsId=" << pUdrFormat->get_ItemA()->get_unMsId() <<endl;
		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "nOperationID=" << pUdrFormat->get_LimitInfo()->get_nOperationID() <<endl;
		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "strAccountSessionID=" << pUdrFormat->get_ItemC()->get_strAccountSessionID() <<endl;
		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "strCorrelationID=" << pUdrFormat->get_ItemC()->get_strCorrelationID() <<endl;
		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "�ѵ��ܾ�=" << pUdrFormat->get_LimitInfo()->get_nLimitPrice() <<endl;
		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "N-top ������ð�=" << pUdrFormat->get_LimitInfo()->get_nNtopFreeTime() <<endl;
	}	
	if( 0 )
	{
		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
			<< "============ ���� ������ȸ ��� ===========" <<  endl;
		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "MsId=" << pSearchUdrFormat->get_ItemA()->get_unMsId() <<endl;
		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "nOperationID=" << pSearchUdrFormat->get_LimitInfo()->get_nOperationID() <<endl;
		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "strAccountSessionID=" << pSearchUdrFormat->get_ItemC()->get_strAccountSessionID() <<endl;
		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "���� strlen=" << strlen( pUdrFormat->get_ItemC()->get_strAccountSessionID() ) <<endl;
		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "���� strlen=" << strlen( pSearchUdrFormat->get_ItemC()->get_strAccountSessionID() ) <<endl;
		
	}	
	nNewOperationID = pUdrFormat->get_LimitInfo()->get_nOperationID();
	nLastOperationID = pSearchUdrFormat->get_LimitInfo()->get_nOperationID();
	
	if( nNewOperationID > nLastOperationID )
	{
		*AggregatorLogM << AggregatorLogM->ErrorCode(4206) 
				<< "Error Operation ID!!" << endl;
		return 0;
	}
	
	// Account Session ID�� �������� update�Ѵ�.
	// ������ ���� ������Ű��, Ư�������� update��Ų��.
	if(  !memcmp( pUdrFormat->get_ItemC()->get_strAccountSessionID(), 			\
				  pSearchUdrFormat->get_ItemC()->get_strAccountSessionID(), 	\
//				  LEN_ACCOUNT_SESSION_ID ) )
				  strlen( pSearchUdrFormat->get_ItemC()->get_strAccountSessionID() ) ) )
	{
		if( 1 )
		{
			*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< " �ѵ����� Update ����." <<  endl;
		}	
		memcpy( pTempUdrFormat, pSearchUdrFormat, sizeof( UdrFormat ) );
		pTempUdrFormat->get_LimitInfo()->put_nLimitPrice( pUdrFormat->get_LimitInfo()->get_nLimitPrice() );
		pTempUdrFormat->get_LimitInfo()->put_nNtopFreeTime( pUdrFormat->get_LimitInfo()->get_nNtopFreeTime() );
		pTempUdrFormat->get_LimitInfo()->put_nQueryResult( 1 );
		// Memroy DB�� file�� ���ÿ� update�ϱ� ���Ͽ� .....
		if( UpdateAggregator( pTempUdrFormat ) )
		{
			*AggregatorLogM << AggregatorLogM->ErrorCode(4224) 
				<< "Aggregator : UpdateAggregator Error!!!" << endl;
			return 0;
	 	}
	 	if( 1 )
		{
			*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "============ UPDATE�� ��� ===========" <<  endl;
			*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
					<< "�ѵ��ܾ�=" << pTempUdrFormat->get_LimitInfo()->get_nLimitPrice() <<endl;
			*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
					<< "N-top ������ð�=" << pTempUdrFormat->get_LimitInfo()->get_nNtopFreeTime() <<endl;
		}
 	}
 	else
 	{
 		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< " Account Session ID�� �ٸ�." <<  endl;
 	}
	
	delete pTempUdrFormat;
	return 1;
}
//===============================================================
// InterimAccountRequestResult Method		   					=
//  : SCP�κ��� �߰������û�� ���� ������ ������ ó���ϴ� Method  		=
// argument     :  pUdrFormat -> ó���ϱ� ���� ���� UdrFormat	=
//				   pSearchUdrFormat -> ������ MDB�� �ִ� DATA		=
// return value : 1-> success									=
//                0-> fail										=
//																=
//===============================================================
int	CAggregator::InterimAccountRequestResult( UdrFormat* pUdrFormat, UdrFormat* pSearchUdrFormat )
{
	int 		nNewOperationID;
	int 		nLastOperationID;
	UdrFormat*	pTempUdrFormat;
	
	// �ӽ� ��������� �Ҵ��Ѵ�.
	pTempUdrFormat = new UdrFormat;

	if( 1 )
	{
		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
			<< "============�����ڿ�� �߰����� ���===========" <<  endl;
		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
			<< "MsId=" << pUdrFormat->get_ItemA()->get_unMsId() <<endl;
		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
			<< "nOperationID=" << pUdrFormat->get_LimitInfo()->get_nOperationID() <<endl;
		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
			<< "strAccountSessionID=" << pUdrFormat->get_ItemC()->get_strAccountSessionID() <<endl;
		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
			<< "strCorrelationID=" << pUdrFormat->get_ItemC()->get_strCorrelationID() <<endl;
		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
			<< "�ѵ��ܾ�=" << pUdrFormat->get_LimitInfo()->get_nLimitPrice() <<endl;
		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
			<< "N-top ������ð�=" << pUdrFormat->get_LimitInfo()->get_nNtopFreeTime() <<endl;
		
	}	
	
	nNewOperationID = pUdrFormat->get_LimitInfo()->get_nOperationID();
	nLastOperationID = pSearchUdrFormat->get_LimitInfo()->get_nOperationID();
	
	if(  nLastOperationID < nNewOperationID )
	{
		*AggregatorLogM << AggregatorLogM->ErrorCode(4206) 
				<< "Error Operation ID!!" << endl;
		return 0;
	}
	else if( nLastOperationID = nNewOperationID )
	{
			// ������ ���� ������Ű��, Ư�������� update��Ų��.
		memcpy( pTempUdrFormat, pSearchUdrFormat, sizeof( UdrFormat ) );
		pTempUdrFormat->get_LimitInfo()->put_nLimitPrice( pUdrFormat->get_LimitInfo()->get_nLimitPrice() );
		pTempUdrFormat->get_LimitInfo()->put_nNtopFreeTime( pUdrFormat->get_LimitInfo()->get_nNtopFreeTime() );
		pTempUdrFormat->get_LimitInfo()->put_nQueryResult( 1 );
		// Memroy DB�� file�� ���ÿ� update�ϱ� ���Ͽ� .....
		if( UpdateAggregator( pTempUdrFormat ) )
		{
			*AggregatorLogM << AggregatorLogM->ErrorCode(4224) 
				<< "Aggregator : UpdateAggregator Error!!!" << endl;
			return 0;
	 	}
		if( 1 )
		{
			*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "============ UPDATE�� ��� ===========" <<  endl;
			*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "�ѵ��ܾ�=" << pTempUdrFormat->get_LimitInfo()->get_nLimitPrice() <<endl;
			*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "N-top ������ð�=" << pTempUdrFormat->get_LimitInfo()->get_nNtopFreeTime() <<endl;
		}
	}
	else
	{
		*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "passing UDR!!" << endl;
	}
	
	delete pTempUdrFormat;
	return 1;
}
//===============================================================
// _RemainsItem Method		   									=
//  : ������ ������ �����ؾ� �ϴ� �κ��� ������ �ִ� Method	 		=
// argument     :  pUdrFormat -> ó���ϱ� ���� ���� UdrFormat	=
//				   pSearchUdrFormat -> ������ MDB�� �ִ� DATA		=
// return value : None											=
//																=
//===============================================================
void CAggregator::_RemainsItem( UdrFormat* pSearchUdrFormat, UdrFormat* pUdrFormat )
{
	F_TYPE*          pItemF;
	int				 nReleaseIndicator;
	A_INT_TYPE*      pSearchItemA;
	B_TYPE*          pSearchItemB;
	C_TYPE*          pSearchItemC;
	D_TYPE*          pSearchItemD;
	E_TYPE*          pSearchItemE;
	F_TYPE*          pSearchItemF;

	pSearchItemA=pSearchUdrFormat->get_ItemA();
	pSearchItemB=pSearchUdrFormat->get_ItemB();
	pSearchItemC=pSearchUdrFormat->get_ItemC();
	pSearchItemD=pSearchUdrFormat->get_ItemD();
	pSearchItemE=pSearchUdrFormat->get_ItemE();
	pSearchItemF=pSearchUdrFormat->get_ItemF();


	pItemF=pUdrFormat->get_ItemF();
    nReleaseIndicator=pItemF->get_nReleaseIndicator();
	pSearchItemF->put_nReleaseIndicator( nReleaseIndicator );

	pUdrFormat->setItem( pSearchItemA );
	pUdrFormat->setItem( pSearchItemB );
	pUdrFormat->setItem( pSearchItemC );
	pUdrFormat->setItem( pSearchItemD );
	pUdrFormat->setItem( pSearchItemE );
	pUdrFormat->setItem( pSearchItemF );
}
//===============================================================
// InsertAggregator Method					   					=
//  : ���� Insert Transaction�� ȣ���ϴ� Method			  		=
// argument     :  pUdrFormat -> ó���ϱ� ���� ���� UdrFormat	=
// return value : 0-> success									=
//                -1-> fail										=
//																=
//===============================================================
int CAggregator::InsertAggregator( UdrFormat* pUdrFormat )
{
	if( TransactOfAggregate->insertshm( pUdrFormat ) )
	{
		*AggregatorLogM << AggregatorLogM->ErrorCode(4209) 
			<< "insertshm:_TransactionInsert Error!!" << endl;	
		return -1;
	}
	return 0;
}
//===============================================================
// DeleteAggregator Method					   					=
//  :  ���� Delete Transaction�� ȣ���ϴ� Method			  		=
// argument     :  pUdrFormat -> ó���ϱ� ���� ���� UdrFormat	=
// return value : 0-> success									=
//                -1-> fail										=
//																=
//===============================================================
int CAggregator::DeleteAggregator( UdrFormat* pUdrFormat )
{
	if( TransactOfAggregate->deleteshm( pUdrFormat ) == -1 )
	{
		*AggregatorLogM << AggregatorLogM->ErrorCode(4210) 
			<< "deleteshm:_TransactionDelete Error!!" << endl;	
		return -1;
	}
	return 0;
}
//===============================================================
// UpdateAggregator Method					   					=
//  : ���� Update Transaction�� ȣ���ϴ� Method			  		=
// argument     :  pUdrFormat -> ó���ϱ� ���� ���� UdrFormat	=
// return value : 0-> success									=
//                -1-> fail										=
//																=
//===============================================================
int CAggregator::UpdateAggregator( UdrFormat* pUdrFormat )
{
	if( TransactOfAggregate->updateshm( pUdrFormat ) )
	{
		*AggregatorLogM << AggregatorLogM->ErrorCode(4208) 
			<< "updateshm:_TransactionUpdate Error!!" << endl;	
		return -1;
	}
	return 0;
}

int main(int argc, char* argv[])
{
	UdrFormat   	stUdr;
	CAggregator* 	pAggregator;
	

	if( argc != 7 )
	{
		cout << "Usage Aggregator [SysId][SerId][GroupId][ProcessId][SerialNumber][Remark]" << endl;
		exit( 1 );
	}
	
	SystemId=atoi(argv[1]);
	ServiceId=atoi(argv[2]);
	GroupId=atoi(argv[3]);
	ProcessType=atoi(argv[4]);
	PserialNo=atoi(argv[5]);
	PreMark=atoi(argv[6]);
	
	
	AggregatorLogM	= new SendLogManage(SystemId,ServiceId,GroupId ,ProcessType ,PserialNo, PreMark );
	AggregatorLogM->put_EventHistData(FLAG_START, FLAG_PROC_START);
	
	//signal(SIGNULL,sigCapture);	//0
	signal(SIGHUP,sigCapture);
	signal(SIGINT,sigCapture);
	signal(SIGQUIT,sigCapture);
	signal(SIGKILL,sigCapture);
	signal(SIGTERM,sigCapture);
	signal(SIGSTOP,sigCapture);
	signal(SIGTSTP,sigCapture);
	signal(SIGCONT,sigCapture);	//26
	signal(SIGUSR1,sigCapture);
	
	ReadAggregator = new MessageQueue<UdrFormat>(SystemId,ServiceId,GroupId ,ProcessType ,PserialNo ,10 ,1000);
	MqUdr = new MessageQueue<UdrFormat>(SystemId,ServiceId,5,2,0,10,1000 );
	mqSCP = new MessageQueue<SCPFormatAgg>(SystemId,ServiceId,4,1,0,10,1000 );
	mqPMS = new MessageQueue<MsgPmsStatus>(SystemId, 0,1,1,0,10, 1000);
	WritePMSMQ(FLAG_PROC_START);
	// ������ number error check�� �ؾ� �ϰ�
	// �ߺ�check�� �ؾ� �մϴ�.
	pAggregator = new CAggregator( SystemId,ServiceId,GroupId,ProcessType,PserialNo,PreMark );
   
    while(1)
	{
		
		memset((char*)&stUdr, NULL, sizeof(UdrFormat));
		
	    if (ReadAggregator->recvMsg(&stUdr) == FLAG_MQ_IS_EMPTY)
	    {
//	        cout << "==Recv=NO DATA IN MessageQueue====="   << endl;
		    sleep(1);
		}
		else 
		{
			//	MakeLimitUdr( &stUdr );
			*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "==============START   Aggregator==============" << endl;
			pAggregator->Aggregator( &stUdr );
	    	*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
				<< "==============End     Aggregator==============" << endl;
		}
	}
	
	*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
			<< "End Aggregator Process!!" << endl;
	delete ReadAggregator;
	delete MqUdr;
	delete mqSCP;
	delete pAggregator;
	delete mqPMS;
	AggregatorLogM->put_EventHistData(FLAG_END, 0);
	delete AggregatorLogM;
	return 0;
}
//===============================================================
// WritePMSMQ Method		     			   					=
//  : PMS���� Process�� ���¸� �����ϱ� ���� Method					=
//	                                    						=
// argument     :  sigNo -> Signal Number						=
// return value : None											=
//																=
//===============================================================
void WritePMSMQ(int sigNo )
{
	int 			i=0;
	char 			PMSMQ_NO[2];
	MsgPmsStatus	OneRec(MSG_STATUS, SystemId, ServiceId, GroupId, ProcessType, PserialNo, PreMark);

	
	sprintf(PMSMQ_NO, "%d", SystemId);
	OneRec.set_nStatus(sigNo);
	
	while(1)
	{
		i++;
		if (mqPMS->sendMsg(&OneRec) == FLAG_MQ_IS_FULL)
		{
			cout << "[ERROR] PMSMQ " << PMSMQ_NO << " IS FULL sleep(1)...!"	<< endl;
			sleep(1);
			if (i >= 10)
			{
				kill(0,SIGINT);
			}
		}else break;
	}
}
//===============================================================
// sigCapture Method		     			   					=
//  : Process���� signal capture	�ϴ� Method      				=
//	                                    						=
// argument     :  sigNo -> Signal Number						=
// return value : None											=
//																=
//===============================================================
void sigCapture(int sigNo )
{
	cout << "SIGNAL :: Aggregator" << PserialNo << "Process End " << endl;
	delete ReadAggregator;
	delete MqUdr;
	delete mqSCP;
	

	switch(sigNo)
	{
		case SIGINT :
		case SIGQUIT :
		case SIGKILL :
		case SIGTERM :
				*AggregatorLogM << AggregatorLogM->ErrorCode(4213) 
					<< "Aggregator Process Killed!! " <<endl;
				WritePMSMQ(FLAG_PROC_KILL);//-1//���μ��� ������ stop (killed)
				AggregatorLogM->put_EventHistData(FLAG_END, -1);
				delete AggregatorLogM;
				delete mqPMS;
				exit(-1);
				break;
		case SIGUSR1:
				*AggregatorLogM << AggregatorLogM->ErrorCode(0) 
					<< "Aggregator Process Normal Stop!! " <<endl;
				WritePMSMQ(FLAG_PROC_TERM);//0//���μ�������stop (Client��������)
				AggregatorLogM->put_EventHistData(FLAG_END, 0);
				delete AggregatorLogM;
				delete mqPMS;
				exit(0);
				break;
		default:
				*AggregatorLogM << AggregatorLogM->ErrorCode(4213) 
					<< "Aggregator Process Killed2!! " <<endl;
				WritePMSMQ(FLAG_PROC_KILL);//-1//���μ��� ������ stop (killed)
				AggregatorLogM->put_EventHistData(FLAG_END, -1);
				delete AggregatorLogM;
				delete mqPMS;
				exit(-1);
				break;
	}
}



