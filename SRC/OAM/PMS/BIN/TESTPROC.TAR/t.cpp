#include <iostream.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include <errno.h>
#include "ipcMQ.hpp"

void WriteMQ(char wType);
int Stop = 1;

int main(int argc, char* argv[])
{
	WriteMQ('S');
	
	static struct sigaction act;
	void ExitProc(int);
	act.sa_handler = ExitProc;
	sigaction(SIGINT, &act, NULL);
	
	while(Stop)
	{
		for(int x = 0 ; x < argc ; x ++ )
			cout << argv[x] << " ";
		cout << endl;
		sleep(3);
	}
	
	return 0;
}

void ExitProc(int signo)
{
	WriteMQ('T');
	Stop = 0;
}

void WriteMQ(char wType)
{
	if (wType != 'S' && wType != 'T')
	{
		cout << "wrong Write MQ type" << endl;
		return ;
	}

	char id[3];
	MessageQueueC MQ (0x8000);
	char pid[6+1];
		
	sprintf (pid, "%c%ld", wType, getpid());
	
	if ( MQ.CreateIPCMQ() == 0)
	{
		if (MQ.WriteIPCMQEx(pid, 7))
			cout << "===============>WriteIPCMQ :"<< id << endl;
		else
			cout << "===============>Fail to WriteIPCMQEx  " << strerror(errno)<<endl;
	}
	else
		cout << "WriteIPCMQ is " << strerror(errno) << endl;
}
