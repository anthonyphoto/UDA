#include <LogManagement.hpp>


LogManagement::LogManagement(	int		nSystemId,
								int		nServiceId,
								int		nGroupId,
								int		nProcessType,
								int		nSerialNo,
								int		nRemark,
								int		nCount
							)
{
	clsMsgLog	= new MsgLog(		MSG_LOG,
									nSystemId,
             						nServiceId,
									nGroupId,
									nProcessType,
									nSerialNo,
									nRemark		);

	LogQ		= new MessageQueue<MsgLog>(	1, 1, 1, 2, 0, 10, 2000 );
	m_ostring	= new ostrstream();
}

LogManagement::~LogManagement()
{
	delete	clsMsgLog;
	delete	LogQ;
	delete	m_ostring;
}

LogManagement& LogManagement::operator<<(const char* str)
{
    *m_ostring << str;
    return *this;
}

LogManagement& LogManagement::operator<<(int n)
{
    *m_ostring << n;
    return *this;
}

LogManagement& LogManagement::operator<<(unsigned int n)
{
    *m_ostring << n;
    return *this;
}

LogManagement& LogManagement::operator<<(char c)
{
    *m_ostring << c;
    return *this;
}

LogManagement& LogManagement::operator<<(short s)
{
    *m_ostring << s;
    return *this;
}

LogManagement& LogManagement::operator<<(long l)
{
    *m_ostring << l;
    return *this;
}

LogManagement& LogManagement::operator<<(float f)
{
    *m_ostring << f;
    return *this;
}

LogManagement& LogManagement::operator<<(double d)
{
    *m_ostring << d;
    return *this;
}

LogManagement& LogManagement::operator<<(unsigned char c)
{
    *m_ostring << c;
    return *this;
}

LogManagement& LogManagement::operator<<(unsigned short s)
{
    *m_ostring << s;
    return *this;
}

LogManagement& LogManagement::operator<<(unsigned long l)
{
    *m_ostring << l;
    return *this;
}

LogManagement& LogManagement::operator<<(void* v)
{
    *m_ostring << v;
    return *this;
}

LogManagement& LogManagement::operator<<(ostream&(*)(ostream&))
{
    *m_ostring << ends;
    clsMsgLog->put_strMsg(get_string(), get_StringLength());

    LogQ->sendMsg(clsMsgLog);

	delete	m_ostring;
	m_ostring	= new ostrstream();

    cout << "LogManagement& LogManagement::operator<<(ostream&(*)(ostream&))" << endl;

    return *this;
}

const char* LogManagement::get_string(void)
{
    return m_ostring->str();
}

int LogManagement::get_StringLength(void)
{
//	return m_ostring->pcount();
	return (strlen(m_ostring->str()));
}

int LogManagement::writeLog()
{
	fLogFile = new ofstream(clsMsgLog->get_ProcessId(), ios::out );

	fLogFile->write(reinterpret_cast<const char*>(clsMsgLog), sizeof(MsgLog));
	fLogFile->close();

	delete fLogFile;

	return 0;
}

/*
int main(int argc, char* argv[])
{
	if(argc < 7)
	{
		cout << "Check your arg !!!" << endl;
		exit(-1);
	}

	LogManagement	clsLogM(atoi(argv[1]), atoi(argv[2]), atoi(argv[3]),
							atoi(argv[4]), atoi(argv[5]), atoi(argv[6]));

	for (int i = 0; i < 10; i++)
	{
		clsLogM << 1000 << "This is a test !!!!" << endl;
		sleep (2);
	}
}
*/

/*
	include\MsgFormat.hpp ������
*/

