#include <unistd.h>
#include <TempMsgQ_new.hpp>
#include <time.hpp>
#include <stdlib.h>

#include <MsgFormat.hpp>

int main(int argc, char* argv[])
{
	MessageQueue<MsgLog>  DataNode1(	atoi(argv[1]), atoi(argv[2]), atoi(argv[3]),\
										atoi(argv[4]), atoi(argv[5]), atoi(argv[6]), atoi(argv[7]));
										
	MsgLog	OneRec(	MSG_LOG, atoi(argv[1]), atoi(argv[2]), atoi(argv[3]),
					atoi(argv[4]), atoi(argv[5]), atoi(argv[6]));
	
	DateTime	CdateTime;

//	OneRec.putData();

	cout << "\nStart Recv Time = [" << CdateTime.get_time(1) << "]" << endl;

	while(1)
	{
		memset ((char*)&OneRec, NULL, sizeof(MsgLog));

		if (DataNode1.recvMsg(&OneRec) == FLAG_MQ_IS_EMPTY)
		{
			OneRec.displayValue();
			cout << "==MQ is Empty========================"	<< endl;
			cout << "==Recv================================"	<< endl;

			sleep (1);

			continue;

//			break;
		}
		OneRec.displayValue();
		cout << "==Recv================================"	<< endl;
	}

	cout << "\nEnd Recv Time = [" << CdateTime.get_time(1) << "]" << endl;


	return 0;
}
