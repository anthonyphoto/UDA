/****************************************************************************/
/* �� �� �� : scpif_s.cpp													*/
/* �� �� �� : KSI / ����								                    */
/* ��    �� : SCP-IF : S-Channel ���� ���α׷�								*/
/* �ۼ����� : 2000�� 10�� 23��                                              */
/* �������� :     ��   ��   ��                                              */
/* ����ȭ�� : SRchannel_IF.hpp, scp_msg.hpp scpformat.hpp					*/
/* ��    Ÿ :                                                               */
/****************************************************************************/
#include "SRchannel_IF.hpp"
#include <TempMsgQ_new.hpp>
#include <MsgFormat.hpp>
//#include <LogManagement.hpp>

int	SystemId;
int	ServiceId;
static int	GroupId;
static int	ProcessType;
static int 	PserialNo;
static int	PreMark;

//--------------------------------------------------------------------
class scpIF_SMAIN {
	
	private:
		SRchannel_IF 				*schIF;
		
		void	Mq_Put_Data();		/* TEST CODE..!! */
		int 	dbWriteAggReq();	// MQ���� ���� Agg�ѵ���û�� DB�� �����Ѵ�. : 0 (���忡��)
		int		dbGetAggReq();		// DB�� ������ �ѵ���û�� �����´�. : 0 (NO data)
		
		
	public:
		scpIF_SMAIN(char *addr, int nport);	//SCP S-Channel �ּҹ� ��Ʈ
		~scpIF_SMAIN(void){ delete schIF; }
		
		void Run(void);						//��Ž���
		void DisConnection(void)
		{
			schIF->DoDisConnection();
		}
};

//--------------------------------------------------------------------

//MessageQueue<SCPFormatAgg> mqSCP("scpformat.txt",    3000,  AGG_JOBID,  AGG_PROID, SCP_JOBID, SCP_PROID);
//MessageQueue<ReCustFormat> mqReCUST("custtoscp.txt",  3000,  GUE_JOBID, GUE_PROID, SCP_JOBID2, SCP_PROID);
MessageQueue<SCPFormatAgg>* mqSCP;		// AGG -> SCPIF_S
MessageQueue<ReCustFormat>* mqReCUST;	// SCPIF_S ->SCPIF_R
MessageQueue<MsgPmsStatus>* mqPMS;
scpIF_SMAIN*	sMain;
SendLogManage*	LogM;



//==============================================================================
void WritePMSMQ(int sigNo)
{
	int 			i=0;
	char 			PMSMQ_NO[2];
	MsgPmsStatus	OneRec(MSG_STATUS, SystemId, ServiceId, GroupId, ProcessType, PserialNo, PreMark);

	
	sprintf(PMSMQ_NO, "%d", SystemId);
	OneRec.set_nStatus(sigNo);
	
	while(1)
	{
		i++;
		if (mqPMS->sendMsg(&OneRec) == FLAG_MQ_IS_FULL)
		{
			cout << "[ERROR] PMSMQ " << PMSMQ_NO << " IS FULL sleep(1)...!"	<< endl;
			sleep(1);
			if (i >= 10)
			{
				kill(0,SIGINT);
			}
		}else break;
	}
}



//==============================================================================
void sigCapture(int sigNo)
{
	cout << "SIGNAL :: Schannel-IF Process End " << endl;
	sMain->DisConnection();
	delete sMain;
	delete mqReCUST;
	delete mqSCP;
	
	switch(sigNo)
	{
		case SIGINT :
		case SIGQUIT :
		case SIGKILL :
		case SIGTERM :
				WritePMSMQ(FLAG_PROC_KILL);//-1//���μ��� ������ stop (killed)
				LogM->put_EventHistData(FLAG_END, -1);
				delete LogM;
				delete mqPMS;
				exit(-1);
				break;
		case SIGUSR1:
				WritePMSMQ(FLAG_PROC_TERM);//0//���μ�������stop (Client��������)
				LogM->put_EventHistData(FLAG_END, 0);
				delete LogM;
				delete mqPMS;
				exit(0);
				break;
		default:
				WritePMSMQ(FLAG_PROC_KILL);//-1//���μ��� ������ stop (killed)
				LogM->put_EventHistData(FLAG_END, -1);
				delete LogM;
				delete mqPMS;
				exit(-1);
				break;
	}
}




//--------------------------------------------------------------------
scpIF_SMAIN::scpIF_SMAIN(char *addr, int nport)
{
	schIF = new SRchannel_IF(addr, nport, SCHANNEL);
}



//--------------------------------------------------------------------
void scpIF_SMAIN::Mq_Put_Data()
{
	/*
	// 0x01 sendMsg
	memset((char*)&fmSCP, 0x00, sizeof(fmSCP));
	fmSCP.get_ItemA2()->set_Key(0x01);
	//fmSCP.get_ItemA()->set_MSID("0112823925     ");	
	fmSCP.get_ItemA2()->set_Min(114300240);	
	fmSCP.get_ItemB()->set_OperId(100);
	fmSCP.get_ItemB()->set_AccSessionId("01234567");
	fmSCP.get_ItemB()->set_CorreId("ABCDEFGH");

	mqSCP->sendMsg(&fmSCP);
	*/
	/*
	// 0x02 sendMsg
	memset((char*)&fmSCP, 0x00, sizeof(fmSCP));
	fmSCP.get_ItemA2()->set_Key(0x02);
	//fmSCP.get_ItemA()->set_MSID("0112825555     ");	
	fmSCP.get_ItemA2()->set_Min(114300240);	
	//fmSCP.get_ItemA2()->set_Min(172825555);	
	fmSCP.get_ItemB()->set_OperId(200);
	fmSCP.get_ItemB()->set_AccSessionId("77777777");
	fmSCP.get_ItemB()->set_CorreId("AAAAAAAA");
	fmSCP.get_ItemC()->set_StartT(600000);
	fmSCP.get_ItemC()->set_EndT(600100);
	fmSCP.get_ItemD()->set_LimitT(1000);
	fmSCP.get_ItemD()->set_NTuseT(500);
	mqSCP->sendMsg(&fmSCP);	
	*/
	
	/*
	// 0x02 sendMsg
	memset((char*)&fmSCP, 0x00, sizeof(fmSCP));
	fmSCP.get_ItemA2()->set_Key(0x02);
	//fmSCP.get_ItemA()->set_MSID("0112820000     ");	
	fmSCP.get_ItemA2()->set_Min(1132820000);	
	fmSCP.get_ItemB()->set_OperId(200);
	fmSCP.get_ItemB()->set_AccSessionId("@888888@");
	fmSCP.get_ItemB()->set_CorreId("#CCCCCC#");
	fmSCP.get_ItemC()->set_StartT(800);
	fmSCP.get_ItemC()->set_EndT(400);
	fmSCP.get_ItemD()->set_LimitT(800);
	fmSCP.get_ItemD()->set_NTuseT(400);
	mqSCP.sendMsg(&fmSCP);	
	
	*/
	
	// 0x03 sendMsg
	memset((char*)&fmSCP, 0x00, sizeof(fmSCP));
	fmSCP.get_ItemA2()->set_Key(0x03);
	fmSCP.get_ItemA2()->set_Min(114300240);	
	//fmSCP.get_ItemA2()->set_Min(1122826666);	
	//fmSCP.get_ItemA()->set_MSID("0112826666     ");	
	mqSCP->sendMsg(&fmSCP);
	
	
	
	
	// 0x04 sendMsg
	memset((char*)&fmSCP, 0x00, sizeof(fmSCP));
	fmSCP.get_ItemA2()->set_Key(0x04);
	fmSCP.get_ItemA2()->set_Min(114300240);	
	//fmSCP.get_ItemB()->set_OperId(300);
	//fmSCP.get_ItemB()->set_AccSessionId("88888888");
	//fmSCP.get_ItemB()->set_CorreId("BBBBBBBB");
	fmSCP.get_ItemC()->set_StartT(700000);
	fmSCP.get_ItemC()->set_EndT(700100);
	fmSCP.get_ItemD()->set_LimitT(1000);
	fmSCP.get_ItemD()->set_NTuseT(600);
	mqSCP->sendMsg(&fmSCP);	
		
}


	
//--------------------------------------------------------------------
void scpIF_SMAIN::Run(void)
{
	int  i,re, idle, chk=0;
	int  first=1;
	int  datamiss=0;	// MQ���� ���� �޽��� ���۽��� (�������ʿ�)
	int	 conn=0;		// ����õ�Ƚ��
	int	 msgon=1;
	
	/* TEST CODE..!! */
   	//Mq_Put_Data();	
	/* TEST CODE..!! */
		
	first=1;
	sleep(1);
	while(1)
	{
		if(first) {
			if(schIF->DoConnection()==FA) 
			{	// ��������ϸ� 30���Ŀ� �ٽýõ�.. 
				cout << "[SCHANNEL] Connection ERROR!! Reconneting..!! " << endl;
				*LogM << "[SCHANNEL] Connection ERROR!! Reconneting..!! :" << LogM->ErrorCode(8202) << endl;
				WritePMSMQ(FLAG_NW_ERROR);
				
				conn++;
				if(conn>3)
				{	// ������ ���������� 3���̻� �����ϸ� Rü�ε� ���� �ٽ� �����ϵ��� �Ѵ�.
					fmReCust.set_Result(0);
					fmReCust.set_UTransactionID(0);
					mqReCUST->sendMsg(&fmReCust);
				}
				
				sleep(RECONNECT_WAIT_TIME);
				msgon=1;
				continue;
			}
			conn=i=idle=first=0;
			WritePMSMQ(FLAG_NW_NORMAL);
		}
		
		// IMSI...R-CHANNEL �ٱ���� ��޸���.		
		//sleep(5);
		
		if(idle>90) // 20->90
   		{	// ������ �޽����� �ѵ��� ������ �������¸� Ȯ���Ѵ�.
			idle=0;
			if(schIF->ProcessCHK()!=SC) 
   			{
   				cout << "[SCHANNEL] Process-CHK ERROR!! Reconneting..!! " << endl;
   				*LogM << "[SCHANNEL] Process-CHK ERROR!! Reconneting..!! :" << LogM->ErrorCode(8203) << endl;
   				first=1;
   				
   				// Rä�� �����û
   				fmReCust.set_Result(0);
				fmReCust.set_UTransactionID(0);
				mqReCUST->sendMsg(&fmReCust);
				
   				sleep(RECONNECT_WAIT_TIME);
   				msgon=1;
   				continue;
   			}   				
   		} 
   		
   		
		if(!datamiss)
		{
			memset((char*)&fmSCP, 0x00, sizeof(fmSCP));
			if(mqSCP->recvMsg(&fmSCP) == FLAG_MQ_IS_EMPTY)	// AGG�κ��� �޽�������
			{
				if(msgon==1)
				{
					printf("[SCHANNEL] mqSCP NO DATA IN MessageQueue\r\n");
					*LogM << "[SCHANNEL] mqSCP NO DATA IN MessageQueue :" << LogM->ErrorCode(0) << endl;
				}
				sleep(1);
				idle++;
				
				/*
				memset((char*)&fmReCust, 0x00, sizeof(fmReCust));
				if(mqReCUST->recvMsg(&fmReCust) == FLAG_MQ_IS_EMPTY) // ���������κ��� �޽�������
				{
					printf("[SCHANNEL] mqReCUST NO DATA IN MessageQueue\r\n");
					sleep(1);
					idle++;
					continue;
				}else 
				{
					chk=2;
					fmReCust.prn_Result();
					fmReCust.prn_UTransactionID();
				}
				*/
				msgon=0;
				continue;	
			}else chk=1;
			//sleep(5);	// TEST...TEST
		} 
		
		
		msgon=1;
		// fmSCP�� ���� DownLoad or UploadResult ���θ� �ľ��ؾ��� (��ƾ�����ʿ�)
		idle=0;
		if(chk==1)
		{
			if((re=schIF->DownLoad(&fmSCP))!=SC) 
   			{
   				if(re!=RELEASE_CLOSE) 
   				{
   					cout << "[SCHANNEL] DownLoad ERROR!! Reconneting..!! " << endl;
   					*LogM << "[SCHANNEL] DownLoad ERROR!! Reconneting..!!" << LogM->ErrorCode(0) << endl;
   				}
 				first=1;
   				datamiss=1;
   				
   				// Rä�� �����û
   				fmReCust.set_Result(0);
				fmReCust.set_UTransactionID(0);
				mqReCUST->sendMsg(&fmReCust);
				
   				sleep(RECONNECT_WAIT_TIME);
   			}else datamiss=0;
   		}
   		/*
   		else if(chk==2)
   		{
   			if((re=schIF->UploadResult(&fmReCust))!=SC)
   			{
   				if(re!=RELEASE_CLOSE) cout << "[SCHANNEL] UploadResult ERROR!! Reconneting..!! " << endl;
 				first=1;
   				datamiss=1;
   				sleep(RECONNECT_WAIT_TIME);
   			}else datamiss=0;
   		}
   		*/
   		
	} // end of while(1)
	
	
	schIF->DoDisConnection();
}




//==============================================================================
int main(int argc, char **argv)
{
	int  i, idle;
	int  first=1;
	
	if(argc !=9)
	{
		cout <<"Usage:" << argv[0] << "[systemid] [serviceid] [groupid] [processtype] [serialno] [remarks] [ipaddr] [port]" << endl;
		exit(-2);
	}
	
	SystemId=atoi(argv[1]);
	ServiceId=atoi(argv[2]);
	GroupId=atoi(argv[3]);
	ProcessType=atoi(argv[4]);
	PserialNo=atoi(argv[5]);
	PreMark=atoi(argv[6]);
	
	//signal(SIGNULL,sigCapture);	//0
	signal(SIGHUP,sigCapture);
	signal(SIGINT,sigCapture);
	signal(SIGQUIT,sigCapture);
	signal(SIGKILL,sigCapture);
	signal(SIGTERM,sigCapture);
	signal(SIGSTOP,sigCapture);
	signal(SIGTSTP,sigCapture);
	signal(SIGCONT,sigCapture);	//26
	signal(SIGUSR1,sigCapture);
	

	mqSCP = new MessageQueue<SCPFormatAgg>(SystemId, ServiceId, GroupId, ProcessType, PserialNo, 10, 1000);//AGG
	mqReCUST = new MessageQueue<ReCustFormat>(SystemId, ServiceId, GroupId, ProcessType, PserialNo, 11, 1000);	//SCP_IF
	mqPMS = new MessageQueue<MsgPmsStatus>(SystemId, 0,1,1,0,10, 1000);
	LogM = new SendLogManage(SystemId, ServiceId, GroupId, ProcessType, PserialNo, PreMark);
	
	LogM->put_EventHistData(FLAG_START, 0);
	
	*LogM << "Argv : " << SystemId << "/" << ServiceId << "/" << GroupId <<"/" << ProcessType 
		<< "/" << PserialNo <<"/" << PreMark << "/" << argv[7] <<"/" << atoi(argv[8]) << endl;
	
	sMain = new scpIF_SMAIN(argv[7], atoi(argv[8]));

	sMain->Run();


	LogM->put_EventHistData(FLAG_END, 0);
	delete LogM;
	delete sMain;
	delete mqReCUST;
	delete mqSCP;
	delete mqPMS;
	
	exit(0);
}
	




